<?php
class ControllerController extends Controller {
	public function index() {		
	
	$this->db->query("UPDATE `" . DB_PREFIX . "country` SET `iso_code_2` = 'VI' WHERE `country_id` = '300001'");
	$this->db->query("UPDATE `" . DB_PREFIX . "country` SET `iso_code_2` = 'VO' WHERE `country_id` = '300002'");
	$this->db->query("UPDATE `" . DB_PREFIX . "country` SET `iso_code_2` = 'DN' WHERE `country_id` = '300003'");
	$this->db->query("UPDATE `" . DB_PREFIX . "country` SET `iso_code_2` = 'DO' WHERE `country_id` = '300004'");
	$this->db->query("UPDATE `" . DB_PREFIX . "country` SET `iso_code_2` = 'ZH' WHERE `country_id` = '300005'");
	$this->db->query("UPDATE `" . DB_PREFIX . "country` SET `iso_code_2` = 'ZK' WHERE `country_id` = '300006'");
	$this->db->query("UPDATE `" . DB_PREFIX . "country` SET `iso_code_2` = 'ZA' WHERE `country_id` = '300007'");
	$this->db->query("UPDATE `" . DB_PREFIX . "country` SET `iso_code_2` = 'IV' WHERE `country_id` = '300008'");
	$this->db->query("UPDATE `" . DB_PREFIX . "country` SET `iso_code_2` = 'KV' WHERE `country_id` = '300009'");
	$this->db->query("UPDATE `" . DB_PREFIX . "country` SET `iso_code_2` = 'KR' WHERE `country_id` = '300010'");
	$this->db->query("UPDATE `" . DB_PREFIX . "country` SET `iso_code_2` = 'LU' WHERE `country_id` = '300011'");
	$this->db->query("UPDATE `" . DB_PREFIX . "country` SET `iso_code_2` = 'LV' WHERE `country_id` = '300012'");
	$this->db->query("UPDATE `" . DB_PREFIX . "country` SET `iso_code_2` = 'MY' WHERE `country_id` = '300013'");
	$this->db->query("UPDATE `" . DB_PREFIX . "country` SET `iso_code_2` = 'OD' WHERE `country_id` = '300014'");
	$this->db->query("UPDATE `" . DB_PREFIX . "country` SET `iso_code_2` = 'PO' WHERE `country_id` = '300015'");
	$this->db->query("UPDATE `" . DB_PREFIX . "country` SET `iso_code_2` = 'RI' WHERE `country_id` = '300016'");
	$this->db->query("UPDATE `" . DB_PREFIX . "country` SET `iso_code_2` = 'SU' WHERE `country_id` = '300017'");
	$this->db->query("UPDATE `" . DB_PREFIX . "country` SET `iso_code_2` = 'TE' WHERE `country_id` = '300018'");
	$this->db->query("UPDATE `" . DB_PREFIX . "country` SET `iso_code_2` = 'KH' WHERE `country_id` = '300019'");
	$this->db->query("UPDATE `" . DB_PREFIX . "country` SET `iso_code_2` = 'KE' WHERE `country_id` = '300020'");
	$this->db->query("UPDATE `" . DB_PREFIX . "country` SET `iso_code_2` = 'KM' WHERE `country_id` = '300021'");
	$this->db->query("UPDATE `" . DB_PREFIX . "country` SET `iso_code_2` = 'CK' WHERE `country_id` = '300022'");
	$this->db->query("UPDATE `" . DB_PREFIX . "country` SET `iso_code_2` = 'CH' WHERE `country_id` = '300023'");
	$this->db->query("UPDATE `" . DB_PREFIX . "country` SET `iso_code_2` = 'CV' WHERE `country_id` = '300024'");
	
	///$this->db->query("UPDATE `" . DB_PREFIX . "zone` SET `country_id` = '300025' WHERE `zone_id` = '201682'");
	///$this->db->query("INSERT INTO `" . DB_PREFIX . "country` (`country_id`, `name`, `iso_code_2`, `iso_code_3`, `address_format`, `postcode_required`, `status`) VALUES ('300025', 'Київ', 'KY', 'UKR', '', '0', '1');");

	}
}