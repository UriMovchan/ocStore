<?php
 /*
  * Модуль интеграции с Rozetka https://www.rozetka.com.ua
  * 
  * Юрий Мовчан
  * xyyrma@gmail.com
  */
class ControllerExtensionFeedGoogleMerchantXml extends Controller {
    public function index() {
      set_time_limit(1200); /// ???????????????????
	
	   if ($this->config->get('google_merchant_xml_status')) {
		$this->db->query('CREATE TABLE IF NOT EXISTS ' . DB_PREFIX . 'google_merchant_xml_check (`option_value_id` int(11) NOT NULL, PRIMARY KEY  (`option_value_id`))');
		$this->db->query('TRUNCATE TABLE ' . DB_PREFIX . 'google_merchant_xml_check');
		
		$this->load->model('catalog/gender');
		$this->load->model('catalog/category');
		$this->load->model('catalog/product');
		$this->load->model('catalog/manufacturer');
		
		$categories = $this->config->get('google_merchant_xml_category');	
		
		$output  = '<?xml version="1.0" encoding="UTF-8"?>';
		$output .= '<feed xmlns="http://www.w3.org/2005/Atom" xmlns:g="http://base.google.com/ns/1.0">';
		$output .= '<title>' . $this->config->get('google_merchant_xml_shop_name') . '</title>';
		$output .= '<link rel="self" href="' . HTTPS_SERVER . '"/>';
		$output .= '<updated>' . date('Y-m-d H:i', time()) . '</updated>';

		 		 
		/// products	
       
         foreach($categories as $category_id) {	
			
			
			$products = $this->model_catalog_product->getProducts(array('start' => 0, 'limit' => 1000000, 'filter_category_id' => $category_id));
		 
			foreach($products as $product){
			  if($product['quantity'] > 0){
				  
				$output .= '<item>';
				$output .= '<g:id>' . $product['product_id'] . '</g:id>';
				$output .= '<g:title>' . $product['name'] . ' ' . $product['model'] . '</g:title>';
				$output .= '<g:description><![CDATA[' . $product['description'] . ']]></g:description>';
				$output .= '<g:link>' . $this->url->link('product/product', 'path=' . $category_id . '&product_id=' . $product['product_id']) . '</g:link>';
				$output .= '<g:image_link>' . HTTPS_SERVER . 'image/' . str_replace(" ", "%20", $product['image']) . '</g:image_link>';
				
				$images_query = $this->db->query("SELECT image FROM " . DB_PREFIX . "product_image WHERE product_id = '" . $product['product_id'] . "' ORDER BY sort_order ASC");
				if($images_query->rows){
					foreach($images_query->rows as $image){
						$output .= '<g:additional_image_link>' . HTTPS_SERVER . 'image/' . str_replace(" ", "%20", $image['image']) . '</g:additional_image_link>';
					}
				}
				
				$output .= '<g:availability>in stock</g:availability>';
				
				if($product['special']){
					$output .= '<g:price>' . $product['price'] . '</g:price>';					
					$output .= '<g:sale_price>' . $product['special'] . '</g:sale_price>';
				} else {
					$output .= '<g:price>' . $product['price'] . '</g:price>';					
				}
				
				$manufacturer = $this->model_catalog_manufacturer->getManufacturer($product['manufacturer_id']);
				$output .= '<g:brand>' . $manufacturer['name'] . '</g:brand>';
				$output .= '<g:mpn>' . 	$product['model'] . '</g:mpn>';
					
					
					
				 
				
				  
				  
				  
			$output .= '</item>';
			  } /// if product > 0				
			} /// foreach products
		  } /// foreach categories
		
		
		
	  $output .= '</feed>';

	  	$this->db->query('DROP TABLE ' . DB_PREFIX . 'google_merchant_xml_check');
	  	
	    } else {
		   $output = '<root>Модуль google_merchant_xml отключен</root>';
	    } 
		 
	$output = str_replace(HTTP_SERVER, HTTPS_SERVER, $output);
	
	$this->response->addHeader('Content-Type: application/xml');
	$this->response->setOutput($output);
			

    } 
}