<?php
// Heading
$_['heading_title']    			= 'Google Merchant XML';

// Text
$_['text_feed']          		= 'Каналы продвижения';
$_['text_success']          	= 'Настройки модуля обновлены!';
$_['text_edit']          		= 'Редактировать Google Merchant';
$_['text_extension']         	= 'Каналы продвижения';

// Entry
$_['entry_status']          	= 'Статус:';
$_['entry_data_feed']          	= 'Адрес:';
$_['entry_shop_name']          	= 'Название магазина:';
$_['entry_category']          	= 'Категории:';

// Error
$_['error_permission']          = 'У вас нет прав для управления этим модулем!';
