<?php
class ControllerController extends Controller {
	public function index() {
		
	//	$this->changeNonLatinFileFolderName();			
	
	$this->db->query("UPDATE `" . DB_PREFIX . "country` SET `iso_code_2` = 'VI' WHERE `country_id` = '300001'");
	$this->db->query("UPDATE `" . DB_PREFIX . "country` SET `iso_code_2` = 'VO' WHERE `country_id` = '300002'");
	$this->db->query("UPDATE `" . DB_PREFIX . "country` SET `iso_code_2` = 'DN' WHERE `country_id` = '300003'");
	$this->db->query("UPDATE `" . DB_PREFIX . "country` SET `iso_code_2` = 'DO' WHERE `country_id` = '300004'");
	$this->db->query("UPDATE `" . DB_PREFIX . "country` SET `iso_code_2` = 'ZH' WHERE `country_id` = '300005'");
	$this->db->query("UPDATE `" . DB_PREFIX . "country` SET `iso_code_2` = 'ZK' WHERE `country_id` = '300006'");
	$this->db->query("UPDATE `" . DB_PREFIX . "country` SET `iso_code_2` = 'ZA' WHERE `country_id` = '300007'");
	$this->db->query("UPDATE `" . DB_PREFIX . "country` SET `iso_code_2` = 'IV' WHERE `country_id` = '300008'");
	$this->db->query("UPDATE `" . DB_PREFIX . "country` SET `iso_code_2` = 'KV' WHERE `country_id` = '300009'");
	$this->db->query("UPDATE `" . DB_PREFIX . "country` SET `iso_code_2` = 'KR' WHERE `country_id` = '300010'");
	$this->db->query("UPDATE `" . DB_PREFIX . "country` SET `iso_code_2` = 'LU' WHERE `country_id` = '300011'");
	$this->db->query("UPDATE `" . DB_PREFIX . "country` SET `iso_code_2` = 'LV' WHERE `country_id` = '300012'");
	$this->db->query("UPDATE `" . DB_PREFIX . "country` SET `iso_code_2` = 'MY' WHERE `country_id` = '300013'");
	$this->db->query("UPDATE `" . DB_PREFIX . "country` SET `iso_code_2` = 'OD' WHERE `country_id` = '300014'");
	$this->db->query("UPDATE `" . DB_PREFIX . "country` SET `iso_code_2` = 'PO' WHERE `country_id` = '300015'");
	$this->db->query("UPDATE `" . DB_PREFIX . "country` SET `iso_code_2` = 'RI' WHERE `country_id` = '300016'");
	$this->db->query("UPDATE `" . DB_PREFIX . "country` SET `iso_code_2` = 'SU' WHERE `country_id` = '300017'");
	$this->db->query("UPDATE `" . DB_PREFIX . "country` SET `iso_code_2` = 'TE' WHERE `country_id` = '300018'");
	$this->db->query("UPDATE `" . DB_PREFIX . "country` SET `iso_code_2` = 'KH' WHERE `country_id` = '300019'");
	$this->db->query("UPDATE `" . DB_PREFIX . "country` SET `iso_code_2` = 'KE' WHERE `country_id` = '300020'");
	$this->db->query("UPDATE `" . DB_PREFIX . "country` SET `iso_code_2` = 'KM' WHERE `country_id` = '300021'");
	$this->db->query("UPDATE `" . DB_PREFIX . "country` SET `iso_code_2` = 'CK' WHERE `country_id` = '300022'");
	$this->db->query("UPDATE `" . DB_PREFIX . "country` SET `iso_code_2` = 'CH' WHERE `country_id` = '300023'");
	$this->db->query("UPDATE `" . DB_PREFIX . "country` SET `iso_code_2` = 'CV' WHERE `country_id` = '300024'");
		///$this->db->query("UPDATE `" . DB_PREFIX . "zone` SET `country_id` = '300025' WHERE `zone_id` = '201682'");
		///$this->db->query("INSERT INTO `" . DB_PREFIX . "country` (`country_id`, `name`, `iso_code_2`, `iso_code_3`, `address_format`, `postcode_required`, `status`) VALUES ('300025', 'Київ', 'KY', 'UKR', '', '0', '1');");

	}
	
	
	public function changeNonLatinFileFolderName(){
		set_time_limit(1200);

		$non_latin_images_pathes = $this->db->query("SELECT * FROM " . DB_PREFIX . "product_image WHERE image regexp '[а-яёА-ЯËэЭіїґєІЇҐЄ\']'")->rows;
			foreach($non_latin_images_pathes as $non_latin_images_path){
				$replace_non_latin_images_path = $this->convertNonLatinToLatin($non_latin_images_path['image']);
				$this->db->query("UPDATE " . DB_PREFIX . "product_image SET image='" . $replace_non_latin_images_path . "' WHERE product_image_id = '" . $non_latin_images_path['product_image_id'] . "'");
			}
		
		$non_latin_image_pathes = $this->db->query("SELECT * FROM " . DB_PREFIX . "product WHERE image regexp '[а-яёА-ЯËэЭіїґєІЇҐЄ\']'")->rows;
			foreach($non_latin_image_pathes as $non_latin_image_path){
				$replace_non_latin_image_path = $this->convertNonLatinToLatin($non_latin_image_path['image']);
				$this->db->query("UPDATE " . DB_PREFIX . "product SET image='" . $replace_non_latin_image_path . "' WHERE product_id = '" . $non_latin_image_path['product_id'] . "'");
			}
	
		$this->recurce(DIR_IMAGE .'catalog');
	}
	
	public function recurce($dir){
		$dir = $dir . '/';
	
		if (is_dir($dir)) {
		    if ($dh = opendir($dir)) {
		        while (($file = readdir($dh)) !== false) {
			        

			        if($file != '.' && $file != '..'){
			        	$new_name = $this->convertNonLatinToLatin($file);
						rename($dir . $file, $dir . $new_name);
						if($file != $new_name){
							echo "файл: " . $file . " --> переименован: " . $new_name . "<br>";
						}
			        }

			        if(!is_dir($file)){
				        $this->recurce($dir . $file);
				        
			        }			        
		        }	closedir($dh);
		    }
		}	
	}
	
	public function convertNonLatinToLatin( $str ) {		
		return str_replace( self::nonLatinChars(), self::latinChars(), $str );
	}
	
	private static function nonLatinChars() {
		return array(
			'À', 'à', 'Á', 'á', 'Â', 'â', 'Ã', 'ã', 'Ä', 'ä', 'Å', 'å', 'Ā', 'ā', 'Ă', 'ă', 'Ą', 'ą', 'Ǟ', 'ǟ', 'Ǻ', 'ǻ', 'Α', 'α',
			'Ḃ', 'ḃ', 'Б', 'б',
			'Ć', 'ć', 'Ç', 'ç', 'Č', 'č', 'Ĉ', 'ĉ', 'Ċ', 'ċ', 'Ч', 'ч', 'Χ', 'χ',
			'Ḑ', 'ḑ', 'Ď', 'ď', 'Ḋ', 'ḋ', 'Đ', 'đ', 'Ð', 'ð', 'Д', 'д', 'Δ', 'δ',
			'Ǳ',  'ǲ', 'ǳ', 'Ǆ', 'ǅ', 'ǆ', 
			'È', 'è', 'É', 'é', 'Ě', 'ě', 'Ê', 'ê', 'Ë', 'ë', 'Ē', 'ē', 'Ĕ', 'ĕ', 'Ę', 'ę', 'Ė', 'ė', 'Ʒ', 'ʒ', 'Ǯ', 'ǯ', 'Е', 'е', 'Э', 'э', 'Ε', 'ε', 'ё',
			'Ḟ', 'ḟ', 'ƒ', 'Ф', 'ф', 'Φ', 'φ',
			'ﬁ', 'ﬂ', 
			'Ǵ', 'ǵ', 'Ģ', 'ģ', 'Ǧ', 'ǧ', 'Ĝ', 'ĝ', 'Ğ', 'ğ', 'Ġ', 'ġ', 'Ǥ', 'ǥ', 'Г', 'г', 'Γ', 'γ',
			'Ĥ', 'ĥ', 'Ħ', 'ħ', 'Ж', 'ж', 'Х', 'х',
			'Ì', 'ì', 'Í', 'í', 'Î', 'î', 'Ĩ', 'ĩ', 'Ï', 'ï', 'Ī', 'ī', 'Ĭ', 'ĭ', 'Į', 'į', 'İ', 'ı', 'И', 'и', 'Η', 'η', 'Ι', 'ι',
			'Ĳ', 'ĳ', 
			'Ĵ', 'ĵ',
			'Ḱ', 'ḱ', 'Ķ', 'ķ', 'Ǩ', 'ǩ', 'К', 'к', 'Κ', 'κ',
			'Ĺ', 'ĺ', 'Ļ', 'ļ', 'Ľ', 'ľ', 'Ŀ', 'ŀ', 'Ł', 'ł', 'Л', 'л', 'Λ', 'λ',
			'Ǉ', 'ǈ', 'ǉ', 
			'Ṁ', 'ṁ', 'М', 'м', 'Μ', 'μ',
			'Ń', 'ń', 'Ņ', 'ņ', 'Ň', 'ň', 'Ñ', 'ñ', 'ŉ', 'Ŋ', 'ŋ', 'Н', 'н', 'Ν', 'ν',
			'Ǌ', 'ǋ', 'ǌ', 
			'Ò', 'ò', 'Ó', 'ó', 'Ô', 'ô', 'Õ', 'õ', 'Ö', 'ö', 'Ō', 'ō', 'Ŏ', 'ŏ', 'Ø', 'ø', 'Ő', 'ő', 'Ǿ', 'ǿ', 'О', 'о', 'Ο', 'ο', 'Ω', 'ω',
			'Œ', 'œ', 
			'Ṗ', 'ṗ', 'П', 'п', 'Π', 'π',
			'Ŕ', 'ŕ', 'Ŗ', 'ŗ', 'Ř', 'ř', 'Р', 'р', 'Ρ', 'ρ', 'Ψ', 'ψ',
			'Ś', 'ś', 'Ş', 'ş', 'Š', 'š', 'Ŝ', 'ŝ', 'Ṡ', 'ṡ', 'ſ', 'ß', 'С', 'с', 'Ш', 'ш', 'Щ', 'щ', 'Σ', 'σ', 'ς',
			'Ţ', 'ţ', 'Ť', 'ť', 'Ṫ', 'ṫ', 'Ŧ', 'ŧ', 'Þ', 'þ', 'Т', 'т', 'Ц', 'ц', 'Θ', 'θ', 'Τ', 'τ',
			'Ù', 'ù', 'Ú', 'ú', 'Û', 'û', 'Ũ', 'ũ', 'Ü', 'ü', 'Ů', 'ů', 'Ū', 'ū', 'Ŭ', 'ŭ', 'Ų', 'ų', 'Ű', 'ű', 'У', 'у',
			'В', 'в', 'Β', 'β',
			'Ẁ', 'ẁ', 'Ẃ', 'ẃ', 'Ŵ', 'ŵ', 'Ẅ', 'ẅ',
			'Ξ', 'ξ',
			'Ỳ', 'ỳ', 'Ý', 'ý', 'Ŷ', 'ŷ', 'Ÿ', 'ÿ', 'Й', 'й', 'Ы', 'ы', 'Ю', 'ю', 'Я', 'я', 'Υ', 'υ',
			'Ź', 'ź', 'Ž', 'ž', 'Ż', 'ż', 'З', 'з', 'Ζ', 'ζ',
			'Æ', 'æ', 'Ǽ', 'ǽ', 'а', 'А',
			'ь', 'ъ', 'Ъ', 'Ь',
			
			'\'', 'і', 'І', 'є', 'Є', 'ї', 'Ї', 'ґ', 'Ґ',
		);
	}
	
	private static function latinChars() {
		return array(
			'A', 'a', 'A', 'a', 'A', 'a', 'A', 'a', 'A', 'a', 'A', 'a', 'A', 'a', 'A', 'a', 'A', 'a', 'A', 'a', 'A', 'a', 'A', 'a',
			'B', 'b', 'B', 'b',
			'C', 'c', 'C', 'c', 'C', 'c', 'C', 'c', 'C', 'c', 'CH', 'ch', 'CH', 'ch',
			'D', 'd', 'D', 'd', 'D', 'd', 'D', 'd', 'D', 'd', 'D', 'd', 'D', 'd',
			'DZ', 'Dz', 'dz', 'DZ', 'Dz', 'dz',
			'E', 'e', 'E', 'e', 'E', 'e', 'E', 'e', 'E', 'e', 'E', 'e', 'E', 'e', 'E', 'e', 'E', 'e', 'E', 'e', 'E', 'e', 'E', 'e', 'E', 'e', 'E', 'e', 'e',
			'F', 'f', 'f', 'F', 'f', 'F', 'f',
			'fi', 'fl',
			'G', 'g', 'G', 'g', 'G', 'g', 'G', 'g', 'G', 'g', 'G', 'g', 'G', 'g', 'G', 'g', 'G', 'g',
			'H', 'h', 'H', 'h', 'ZH', 'zh', 'H', 'h',
			'I', 'i', 'I', 'i', 'I', 'i', 'I', 'i', 'I', 'i', 'I', 'i', 'I', 'i', 'I', 'i', 'I', 'i', 'I', 'i', 'I', 'i', 'I', 'i',
			'IJ', 'ij',
			'J', 'j',
			'K', 'k', 'K', 'k', 'K', 'k', 'K', 'k', 'K', 'k',
			'L', 'l', 'L', 'l', 'L', 'l', 'L', 'l', 'L', 'l', 'L', 'l', 'L', 'l',
			'LJ', 'Lj', 'lj',
			'M', 'm', 'M', 'm', 'M', 'm',
			'N', 'n', 'N', 'n', 'N', 'n', 'N', 'n', 'n', 'N', 'n', 'N', 'n', 'N', 'n',
			'NJ', 'Nj', 'nj',
			'O', 'o', 'O', 'o', 'O', 'o', 'O', 'o', 'O', 'o', 'O', 'o', 'O', 'o', 'O', 'o', 'O', 'o', 'O', 'o', 'O', 'o', 'O', 'o', 'O', 'o',
			'OE', 'oe',
			'P', 'p', 'P', 'p', 'P', 'p', 'PS', 'ps',
			'R', 'r', 'R', 'r', 'R', 'r', 'R', 'r', 'R', 'r',
			'S', 's', 'S', 's', 'S', 's', 'S', 's', 'S', 's', 's', 'ss', 'S', 's', 'SH', 'sh', 'SHCH', 'shch', 'S', 's', 's',
			'T', 't', 'T', 't', 'T', 't', 'T', 't', 'T', 't', 'T', 't', 'TS', 'ts', 'TH', 'th', 'T', 't',
			'U', 'u', 'U', 'u', 'U', 'u', 'U', 'u', 'U', 'u', 'U', 'u', 'U', 'u', 'U', 'u', 'U', 'u', 'U', 'u', 'U', 'u',
			'V', 'v', 'V', 'v',
			'W', 'w', 'W', 'w', 'W', 'w', 'W', 'w',
			'X', 'x',
			'Y', 'y', 'Y', 'y', 'Y', 'y', 'Y', 'y', 'Y', 'y', 'Y', 'y', 'YU', 'yu', 'YA', 'ya', 'Y', 'y',
			'Z', 'z', 'Z', 'z', 'Z', 'z', 'Z', 'z', 'Z', 'z',
			'AE', 'ae', 'AE', 'ae', 'a', 'A',
			'', '', '', '',
			
			'', 'i', 'I', 'e', 'e', 'i', 'I', 'g', 'G',
		);
	}	
}