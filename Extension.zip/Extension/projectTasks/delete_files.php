<!DOCTYPE html>
<html>
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		<title>FILE FINDER and REMOVER</title>
		<style>
			body { font-size: 10px; font-family: Arial, Helvetica, sans-serif; background: #FFF; color: #000; }
			.FOUND { color: #F30; font-size: 14px; font-weight: bold; }
		</style>
	</head>
	<body>
		<?php
			$HOME = dirname(__FILE__);

			// Is this a Windows host ? If it is, change this line to $WIN = 1;
			$WIN = 0; // That's all I need
			
			$find = '.DS_Store'; // FILE what we looking FOR

			$deleted = array();
			RecursiveFolder($HOME);
			echo '<h2>Looking for \'' . $find . '\' files</h2><p class="FOUND">';
			if(count($deleted) > 0){
				foreach ($deleted as $del) { 
					echo $del ."<br />\n";
					unlink($del);
				}
			} else {
				echo 'nothing found';
			}
			echo '</p>';
			
			// Recursive finder
			function RecursiveFolder($sHOME) {
				global $deleted, $WIN;
				
				$win32 = ($WIN == 1)? "\\" : "/";
				
				$folder = dir($sHOME);
				
				$foundfolders = array();
				while($file = $folder->read()) {
					if($file != "." && $file != "..") {
						if(filetype($sHOME . $win32 . $file) == "dir"){
							$foundfolders[count($foundfolders)] = $sHOME . $win32 . $file;
						} else {
							if($file == '.DS_Store'){
								$deleted[count($deleted)] = $sHOME . $win32 . $file;
								
							}
						}
					}
				}
				$folder->close();
				
				if(count($foundfolders) > 0) {
					foreach ($foundfolders as $folder) {
						RecursiveFolder($folder, $win32);
					}
				}
			}
		?>
	</body>
</html>