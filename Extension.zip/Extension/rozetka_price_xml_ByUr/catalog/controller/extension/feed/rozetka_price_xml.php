<?php
 /*
  * Модуль интеграции с Rozetka https://www.rozetka.com.ua
  * 
  * Юрий Мовчан
  * xyyrma@gmail.com
  */
class ControllerExtensionFeedRozetkaPriceXml extends Controller {
    public function index() {
      set_time_limit(1200); /// ???????????????????
	
	   if ($this->config->get('rozetka_price_xml_status')) {
		$this->db->query('CREATE TABLE IF NOT EXISTS ' . DB_PREFIX . 'rozetka_price_xml_check (`option_value_id` int(11) NOT NULL, PRIMARY KEY  (`option_value_id`))');
		$this->db->query('TRUNCATE TABLE ' . DB_PREFIX . 'rozetka_price_xml_check');
		
		$this->load->model('catalog/gender');
		$this->load->model('catalog/category');
		$this->load->model('catalog/product');
		$this->load->model('catalog/manufacturer');
		
		$output  = '<?xml version="1.0" encoding="UTF-8"?>';
		$output .= '<!DOCTYPE yml_catalog SYSTEM "shops.dtd">';
		$output .= '<yml_catalog date="' . date('Y-m-d H:i', time()) . '">';
        $output .= '<shop>';
        $output .= ' <name>' . $this->config->get('rozetka_price_xml_shop_name') . '</name>';
        $output .= ' <company>' . $this->config->get('config_name') . '</company>';
        $output .= ' <platform>ocStore</platform>';
        $output .= ' <platform>2.3.0.2</platform>';
        $output .= ' <url>' . HTTPS_SERVER . '</url>';
        $output .= ' <currencies>';
        $output .= '  <currency id="UAH" rate="1"/>';
        $output .= ' </currencies>';

		$tax = $this->config->get('rozetka_price_xml_tax');
		$genders = $this->config->get('rozetka_price_xml_gender');
		$categories = $this->config->get('rozetka_price_xml_category');
		$manufacturers = $this->config->get('rozetka_price_xml_manufacturer');
		/// genders
			if ($genders && $categories) {
			  $output .= '<categories>';
				foreach($genders as $gender_id) {  
					$gender = $this->model_catalog_gender->getGender($gender_id);
					
		/// categories
					foreach($categories as $category_id) {
						$category = $this->model_catalog_category->getCategory($category_id);
			            $output .= '<category id="' . $gender['gender_id'] . $category['category_id'] . '">' . $category['name'] . ' ' . $gender['name'] . '</category>';
					} /// categories
									
				} /// genders
			  $output .= '</categories>';
			} 	
		 		 
		/// products
        $output .= '<offers>';	
        sort($genders);
        foreach($genders as $gender_id) {  
         foreach($categories as $category_id) {	
			$gender = $this->model_catalog_gender->getGender($gender_id);
			
			$products = $this->model_catalog_product->getProducts(array('start' => 0, 'limit' => 1000000, 'gender_id' => $gender_id, 'filter_category_id' => $category_id));
		 
			foreach($products as $product){
				 
				 /// main category check
				$main_category_id = $this->model_catalog_product->getProductMainCategoryId($product['product_id']);
				if($main_category_id == $category_id) {
					
				 /// options
				$options = $this->model_catalog_product->getProductOptions($product['product_id']);
				foreach ($options as $option) {
				  if ($option['option_id'] == 15 || $option['option_id'] == 21) {
					foreach($option['product_option_value'] as $product_option_value) {
					  if($product_option_value['quantity'] > 0) {	
						$output .= '<offer id="' . $product['product_id'] . '-' . $gender_id . $product_option_value['product_option_value_id'] . $product_option_value['option_value_id'] . '" available="true">';
						$output .= '<url>' . $this->url->link('product/product', 'path=' . $category_id . '&product_id=' . $product['product_id']) . '</url>';
						
						
						
						
						
						
						$check_doubles = $this->db->query('SELECT option_value_id FROM ' . DB_PREFIX . 'rozetka_price_xml_check WHERE option_value_id ="' . (int)$product_option_value['product_option_value_id'] . '"')->row;
						if($check_doubles){
							$output .= '<name>' . $product['name'] . ' ' . $product['model'] . ' ' . $gender['name'] . ' ' . $product_option_value['name'] . 'р. ' . $product_option_value['ob_info'] . '</name>';		  
						}else{ 
							$output .= '<name>' . $product['name'] . ' ' . $product['model'] . ' ' . $product_option_value['name'] . 'р. ' . $product_option_value['ob_info'] . '</name>';
							$this->db->query('INSERT INTO ' . DB_PREFIX . 'rozetka_price_xml_check SET option_value_id ="' . (int)$product_option_value['product_option_value_id'] . '"');
						}
						
						
						
						
						
						$manufacturer = $this->model_catalog_manufacturer->getManufacturer($product['manufacturer_id']);
		
						$output .= '<vendor>' . $manufacturer['name'] . '</vendor>';		  
						$output .= '<vendorCode>' . $product['model'] . '</vendorCode>';		  
						$output .= '<categoryId>' . $gender_id . $category_id . '</categoryId>';
						$output .= '<stock_quantity>' . $product_option_value['quantity'] . '</stock_quantity>';		  
				  
						if($product['special']){
							$output .= '<price>' . $product['special'] * $tax . '</price>';					
							$output .= '<old_price>' . $product['price'] * $tax . '</old_price>';
						} else {
							$output .= '<price>' . $product['price'] * $tax . '</price>';					
						}
								  
						$output .= '<currencyId>UAH</currencyId>';
						
						$output .= '<picture>' . HTTPS_SERVER . 'image/' . str_replace(" ", "%20", $product['image']) . '</picture>';
				  
						$images_query = $this->db->query("SELECT image FROM " . DB_PREFIX . "product_image WHERE product_id = '" . $product['product_id'] . "' ORDER BY sort_order ASC");
						if($images_query->rows){
							foreach($images_query->rows as $image){
							  $output .= '<picture>' . HTTPS_SERVER . 'image/' . str_replace(" ", "%20", $image['image']) . '</picture>';
							}
						}
  
						$output .= '<description><![CDATA[' . $product['description'] . ']]></description>';

						$output .= '<param name="' . $option['name'] . '">' . $product_option_value['name'] . 'р.' . ' ' . $product_option_value['ob_info'] . '</param>';
						
						$product_attributes = $this->model_catalog_product->getProductAttributes($product['product_id']);
						foreach($product_attributes as $attribute_group){
						  foreach($attribute_group['attribute'] as $attribute){
							$output .= '<param name="' . $attribute['name'] . '">' . $attribute['text'] . '</param>';
						  }
						}
						

					
						$output .= '</offer>';
						
					  } /// if if options quantity > 0
					} /// foreach options_value		
				  } /// if options == 15 || 21
				} /// foreach options
			  } /// main category check  
				  
				  
				  
				
			} /// foreach products
		  } /// foreach categories
		} /// foreach genders
		
		$output .= '</offers>'; /// products
	  $output .= '</shop>';
	$output .= '</yml_catalog>';
	
	    } else {
		   $output = '<root>Модуль rozetka_price_xml отключен</root>';
	    } 
		 
	$output = str_replace(HTTP_SERVER, HTTPS_SERVER, $output);
	
	$this->db->query('DROP TABLE ' . DB_PREFIX . 'rozetka_price_xml_check');
	
	$this->response->addHeader('Content-Type: application/xml');
	$this->response->setOutput($output);
			

    } 
}