<?php
 /*
  * Модуль интеграции с Rozetka https://www.rozetka.com.ua
  * 
  * Юрий Мовчан
  * xyyrma@gmail.com
  */
class ControllerExtensionFeedRozetkaPriceXml extends Controller {
    private $error = array();

	public function index() {
		$this->load->language('extension/feed/rozetka_price_xml');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('setting/setting');
		$this->load->model('catalog/gender');
		$this->load->model('catalog/category');
		$this->load->model('catalog/manufacturer');

		if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validate()) {
			$this->model_setting_setting->editSetting('rozetka_price_xml', $this->request->post);

			$this->session->data['success'] = $this->language->get('text_success');

			$this->response->redirect($this->url->link('extension/extension', 'token=' . $this->session->data['token'] . '&type=feed', true));
		}

		$data['heading_title'] = $this->language->get('heading_title');

		$data['text_edit'] = $this->language->get('text_edit');
		$data['text_enabled'] = $this->language->get('text_enabled');
		$data['text_disabled'] = $this->language->get('text_disabled');
		$data['text_select_all'] = $this->language->get('text_select_all');
		$data['text_unselect_all'] = $this->language->get('text_unselect_all');
		
		$data['entry_status'] = $this->language->get('entry_status');
		$data['entry_data_feed'] = $this->language->get('entry_data_feed');
		$data['entry_shop_name'] = $this->language->get('entry_shop_name');
		$data['entry_tax'] = $this->language->get('entry_tax');
		$data['entry_gender'] = $this->language->get('entry_gender');
		$data['entry_category'] = $this->language->get('entry_category');
		$data['entry_manufacturer'] = $this->language->get('entry_manufacturer');
		
		$data['button_view'] = $this->language->get('button_view');
		$data['button_save'] = $this->language->get('button_save');
		$data['button_cancel'] = $this->language->get('button_cancel');
	
		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}

		$data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'token=' . $this->session->data['token'], true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_extension'),
			'href' => $this->url->link('extension/extension', 'token=' . $this->session->data['token'] . '&type=feed', true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('extension/feed/rozetka_price_xml', 'token=' . $this->session->data['token'], true)
		);

		$data['action'] = $this->url->link('extension/feed/rozetka_price_xml', 'token=' . $this->session->data['token'], true);

		$data['cancel'] = $this->url->link('extension/extension', 'token=' . $this->session->data['token'] . '&type=feed', true);

		if (isset($this->request->post['rozetka_price_xml_status'])) {
			$data['rozetka_price_xml_status'] = $this->request->post['rozetka_price_xml_status'];
		} else {
			$data['rozetka_price_xml_status'] = $this->config->get('rozetka_price_xml_status');
		}
		
		if (isset($this->request->post['rozetka_price_xml_shop_name'])) {
			$data['rozetka_price_xml_shop_name'] = $this->request->post['rozetka_price_xml_shop_name'];
		} else {
			$data['rozetka_price_xml_shop_name'] = $this->config->get('rozetka_price_xml_shop_name');
		}
		
		if (isset($this->request->post['rozetka_price_xml_tax'])) {
			$data['rozetka_price_xml_tax'] = $this->request->post['rozetka_price_xml_tax'];
		} else {
			$data['rozetka_price_xml_tax'] = $this->config->get('rozetka_price_xml_tax');
		}
		
		if (isset($this->request->post['rozetka_price_xml_gender'])) {
			$data['rozetka_price_xml_gender'] = $this->request->post['rozetka_price_xml_gender'];
		} elseif ($this->config->get('rozetka_price_xml_gender') ) {
			$data['rozetka_price_xml_gender'] = $this->config->get('rozetka_price_xml_gender');
		} else {
			$data['rozetka_price_xml_gender'] = array();
		}
		
		if (isset($this->request->post['rozetka_price_xml_category'])) {
			$data['rozetka_price_xml_category'] = $this->request->post['rozetka_price_xml_category'];
		} elseif ($this->config->get('rozetka_price_xml_category') ) {
			$data['rozetka_price_xml_category'] = $this->config->get('rozetka_price_xml_category');
		} else {
			$data['rozetka_price_xml_category'] = array();
		}
		
		if (isset($this->request->post['rozetka_price_xml_manufacturer'])) {
			$data['rozetka_price_xml_manufacturer'] = $this->request->post['rozetka_price_xml_manufacturer'];
		} elseif ($this->config->get('rozetka_price_xml_manufacturer') ) {
			$data['rozetka_price_xml_manufacturer'] = $this->config->get('rozetka_price_xml_manufacturer');
		} else {
			$data['rozetka_price_xml_manufacturer'] = array();
		}


		$categories_data = $this->model_catalog_category->getCategories();
		foreach($categories_data as $cd){
			if($cd['status'] != 0 && $cd['parent_id'] != 0){
				$categories[] = $cd;
			}
		}
		
		$data['data_feed'] = HTTP_CATALOG . 'index.php?route=extension/feed/rozetka_price_xml';
		$data['genders'] = $this->model_catalog_gender->getGenders();
		$data['categories'] = $categories;
		$data['manufacturers'] = $this->model_catalog_manufacturer->getManufacturers();
		
		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');

		$this->response->setOutput($this->load->view('extension/feed/rozetka_price_xml', $data));
	}

	protected function validate() {
		if (!$this->user->hasPermission('modify', 'extension/feed/rozetka_price_xml')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}

		return !$this->error;
	}
}