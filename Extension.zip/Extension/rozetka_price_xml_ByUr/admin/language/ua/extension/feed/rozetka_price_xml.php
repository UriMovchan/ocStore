<?php
// Heading
$_['heading_title']    			= 'Rozetka Price XML';

// Text
$_['text_feed']          		= 'Каналы продвижения';
$_['text_success']          	= 'Настройки модуля обновлены!';
$_['text_edit']          		= 'Редактировать Rozetka Price';
$_['text_extension']         	= 'Каналы продвижения';

// Entry
$_['entry_status']          	= 'Статус:';
$_['entry_data_feed']          	= 'Адрес:';
$_['entry_shop_name']          	= 'Название магазина:';
$_['entry_tax']          		= 'Наценка:';
$_['entry_gender']          	= 'Пол:';
$_['entry_category']          	= 'Категории:';
$_['entry_manufacturer']        = 'Бренды:';

// Error
$_['error_permission']          = 'У вас нет прав для управления этим модулем!';
